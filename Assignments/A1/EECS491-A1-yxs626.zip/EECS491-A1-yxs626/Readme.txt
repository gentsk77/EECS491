Four sources of preview provided: HTML, notebook, pdf, and markdown.

For better experience, reading with markdown or html is recommended.